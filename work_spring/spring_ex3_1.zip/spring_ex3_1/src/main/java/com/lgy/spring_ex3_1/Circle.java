package com.lgy.spring_ex3_1;

public class Circle {
	public void area(int radius) {
		System.out.println("원의 면적은 "+(3.14*radius*radius));
	}
}
